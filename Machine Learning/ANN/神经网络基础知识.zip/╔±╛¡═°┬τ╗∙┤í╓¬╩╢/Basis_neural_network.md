# Basis of Neural Network
本部分知识点中的向量均为行向量。

## 线性回归（Continuous）
对于估计
$$
\hat{y}=x_1w_1+x_2w_2+b
$$
其中$w_1$和$w_2$是**权重（weight）**，$b$是**偏差（bias）**，且均为标量。它们是**线性回归模型的参数（parameter）**。**模型输出$\hat{y}$是线性回归对真实价格$y$的预测或估计**。我们通常允许它们之间有⼀定误差。

通过数据来寻找特定的模型参数值，使模型在数据上的误差尽可能小的过程叫作**模型训练（model training）**

训练集相关概念不介绍

**损失函数loss function**
    第$i$个样本误差
    $$
    \mathscr{l}^{(i)}(w_1,w_2,b)=\frac{1}{2}\left(\hat{y}^{(i)}-y^{(i)}\right)^2
    $$
    这种误差形成的损失函数为**MSE**：
    $$
    l(w_1,w_2,b)=\frac{1}{n}\sum_{i=1}^n\mathscr{l}^{(i)}(w_1,w_2,b)
    $$
    为使得损失函数最小，有
    $$
    w_1^*, w_2^*, b = \argmin_{w_1,w_2,b} l(w_1,w_2,b)
    $$

**优化算法数值解的方法之一：小批量随机梯度下降`mini-batch stochastic gradient descent）`**
1. 先选取⼀组模型参数的**初始值**，如随机选取；
2. 接下来对参数进⾏**多次迭代**，使每次迭代都可能**降低损失函数的值**。
在每次迭代中，先随机均匀采样⼀个由固定数⽬训练数据样本所组成的**小批量**（mini-batch）$\mathcal{B}$，然后求小批量中数据样本的平均损失有关模型参数的**导数（梯度）**，最后⽤此结果**与预先设定的⼀个正数的乘积作为模型参数在本次迭代的减小量**。
以参数$w_1$为例，
$$
w_1\leftarrow w_1 - \frac{\alpha}{\mathcal{B}}\sum_{i\in\mathcal{B}}\frac{\partial l^{(i)}(w_1,w_2,b)}{\partial{w_1}}
$$
上式中，**$\alpha$为学习率（learning rate）并取正数**，**$\mathcal{B}$代表每个小批量中的样本个数（批量⼤小，batch size）**

当优化算法停止时，$w_1,w_2,b$停止于$\hat{w}_1,\hat{w}_2,\hat{b}$，可能是解析解（最小值）$w_1^*, w_2^*, b$，但大多数情况下，与其有一定的偏差，故这种算法只能获得近似解。

当数据样本数为n，特征数为d时，用矩阵表示，有：
$$
\mathbf{\hat{y}}=\mathbf{Xw}+b
$$
式中，$\mathbf{\hat{y},y}\in \mathbb{R}^{n×1}$

令模型参数向量$\mathbf{\theta}=[w_1,w_2,b]^\mathrm{T}$，有：
$$
l(\theta)=\frac{1}{2n}\mathbf{{(\hat{y}-y)}^\mathrm{T}{(\hat{y}-y)}}
$$
$$
\theta\leftarrow \theta-\frac{\alpha}{\mathcal{B}}\sum_{i in \mathcal{B}}\nabla_\theta l^{(i)}({\theta})=\begin{bmatrix}
x_1^{(i)} \\ x_2^{(i)} \\1
\end{bmatrix}
\left( \hat{y}_i  - y_i\right)
$$

**训练模型**
以上面 ***小批量随机梯度下降*** 讲解
![](2021-02-10-19-33-41.png)

## `softmax`回归（Discrete）
如果
$$
\hat{y}_1,\hat{y}_2,\dots,\hat{y}_N=\mathrm{softmax}\{o_1,o_2,\dots,o_N\}
$$
等价于
$$
    \hat{y}_i=\frac{\exp{o_i}}{\sum_{j=1}^N\exp{o_j}}
$$
上式中，$\sum_{i=1}^N\hat{y}_i=1$且对于$\forall i \in\{1,2,\dots,N\}$，恒有$y_i\geq0$，符合概率的分布；另外，由于
$$
\argmax_i{\hat{y}_i}=\argmax_i{o_i}
$$
不改变类别输出。

**矢量算法**
**1. 单样本**
![](2021-02-10-19-52-04.png)

**2. 小批量样本**
对于 **批量样本为$n$，输⼊个数（特征数）为$d$，输出个数（类别数）为$q$** 小批量样本，有：
$$
\begin{matrix}
\mathbf{O=XW+b} \\
\mathbf{\hat{Y}}=\mathrm{softmax}{(\mathbf{O})}
\end{matrix}
$$
式中，$\mathbf{X} \in \mathbb{R}^{n×d}, \mathbf{W} \in \mathbb{R}^{d×q}, \mathbf{X} \in \mathbb{R}^{1×q}$

### 交叉熵损失函数
- **交叉熵（Cross Entropy）**
$$
H\left(y^{(i)},\hat{y}^{(j)}\right)=-\sum_{j=1}^q y_j^{(i)}\log \hat{y}_j^{(i)}
$$
![](2021-02-10-20-15-09.png)

- **交叉熵损失函数**
$$
l(\Theta)=\frac{1}{n}\sum_{i=1}^n H\left(y^{(i)},\hat{y}^{(j)}\right)
$$
![](2021-02-10-20-19-01.png)